var bucketName = "";
var bucketRegion = "";
var IdentityPoolId = "";
var EncryptionKeyId = "";