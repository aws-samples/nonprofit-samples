var bucketName = "";
var bucketRegion = "";
var IdentityPoolId = "";
var EncryptionKeyId = "";
var userPoolId = "";
var clientId = "";